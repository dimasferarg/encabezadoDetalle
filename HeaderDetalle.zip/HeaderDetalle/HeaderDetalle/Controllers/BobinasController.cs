﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Runtime.Serialization.Json;
using System.Web.Script.Serialization;
using System.Net;
using HeaderDetalle.Models;

namespace HeaderDetalle.Controllers
{
    public class BobinasController : Controller
    {
        private static ICollection<BobinasHWS> bobinas = new HashSet<BobinasHWS>();

        private static readonly ICollection<ProductosWS> productos = new HashSet<ProductosWS>() {
            new ProductosWS { ProductoID = 1, Nombre = "Producto A"},
            new ProductosWS { ProductoID = 2, Nombre = "Producto B"},
            new ProductosWS { ProductoID = 3, Nombre = "Producto C"}
        };

        //string BASE_URL = "http://localhost:2768/ServicioProduccion.svc/";

        public ActionResult Index()
        {
            //BobinasHService ws = new BobinasHService();

            //var webCliente = new WebClient();
            //var json = webCliente.DownloadString(BASE_URL + "seleccionarbobinasH");
            //string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
            //json = s;
            //var js = new JavaScriptSerializer();
            //js.Deserialize<List<BobinasHWS>>(json).ToList();

            var modelo = bobinas.ToArray();
            return View(modelo);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(BobinasHWS modelo, string operacion = null)
        {
            if (modelo == null)
            {
                modelo = new BobinasHWS();
            }

            if (operacion == null)
            {
                if (CrearFactura(modelo))
                {
                    return RedirectToAction("Index");
                }
            }
            else if (operacion == "agregar-detalle")
            {
                modelo.DetalleBobinas.Add(new BobinasDWS());
            }
            else if (operacion.StartsWith("eliminar-detalle-"))
            {
                EliminarDetallePorIndice(modelo, operacion);
            }

            //ProductosService ws = new ProductosService();

            //var webCliente = new WebClient();
            //var json = webCliente.DownloadString(BASE_URL + "seleccionarproductos");
            //string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
            //json = s;
            //var js = new JavaScriptSerializer();
            //js.Deserialize<List<ProductosWS>>(json);
            //var listaProductos = js.Deserialize<List<ProductosWS>>(json).ToList();

            ViewBag.Productos = productos;
            return View(modelo);
        }
        private static void EliminarDetallePorIndice(BobinasHWS factura, string operacion)
        {
            string indexStr = operacion.Replace("eliminar-detalle-", "");
            int index = 0;

            if (int.TryParse(indexStr, out index) && index >= 0 && index < factura.DetalleBobinas.Count)
            {
                var item = factura.DetalleBobinas.ToArray()[index];
                factura.DetalleBobinas.Remove(item);
            }
        }

        private bool CrearFactura(BobinasHWS factura)
        {
            if (ModelState.IsValid)
            {
                if (factura.DetalleBobinas != null && factura.DetalleBobinas.Count > 0)
                {
                    factura.ID = bobinas.Count > 0 ? bobinas.Max(x => x.ID) + 1 : 1;
                    bobinas.Add(factura);
                    return true;
                }
                else
                {
                    ModelState.AddModelError("", "No puede guardar facturas sin detalle");
                }
            }
            return false;
        }
    }
}
