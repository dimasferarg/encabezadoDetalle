﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Runtime.Serialization.Json;
using System.Web.Script.Serialization;
using System.Net;
using HeaderDetalle.Models;

namespace HeaderDetalle.Controllers
{
    public class FacturaController : Controller
    {
        private static ICollection<FacturaHeader> facturas = new HashSet<FacturaHeader>();
        string BASE_URL = "http://localhost:2768/ServicioProduccion.svc/";

        private static readonly ICollection<Producto> productos = new HashSet<Producto>() {
            new Producto { ProductoID = 1, CodigoProducto = "1", Categoria = "AB", Nombre = "Producto A"},
            new Producto { ProductoID = 2, CodigoProducto = "2", Categoria = "BC", Nombre = "Producto B"},
            new Producto { ProductoID = 3, CodigoProducto = "3", Categoria = "CD", Nombre = "Producto C"}
        };

        public ActionResult Index()
        {
            var modelo = facturas.ToArray();
            return View(modelo);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(FacturaHeader modelo, string operacion = null)
        {
            if (modelo == null)
            {
                modelo = new FacturaHeader();
            }

            if (operacion == null)
            {
                if (CrearFactura(modelo))
                {
                    return RedirectToAction("Index");
                }
            }
            else if (operacion == "agregar-detalle")
            {
                modelo.Detalle.Add(new FacturaDetail());
            }
            else if (operacion.StartsWith("eliminar-detalle-"))
            {
                EliminarDetallePorIndice(modelo, operacion);
            }


            //ProductosService ws = new ProductosService();

            var webCliente = new WebClient();
            var json = webCliente.DownloadString(BASE_URL + "seleccionarproductos");
            string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
            json = s;
            var js = new JavaScriptSerializer();
            js.Deserialize<List<ProductosWS>>(json);
            var listaProductos = js.Deserialize<List<ProductosWS>>(json).ToList();
            //ViewBag.Productos = productos;
            ViewBag.Productos = listaProductos;
            return View(modelo);
        }
        private static void EliminarDetallePorIndice(FacturaHeader factura, string operacion)
        {
            string indexStr = operacion.Replace("eliminar-detalle-", "");
            int index = 0;

            if (int.TryParse(indexStr, out index) && index >= 0 && index < factura.Detalle.Count)
            {
                var item = factura.Detalle.ToArray()[index];
                factura.Detalle.Remove(item);
            }
        }

        private bool CrearFactura(FacturaHeader factura)
        {
            if (ModelState.IsValid)
            {
                if (factura.Detalle != null && factura.Detalle.Count > 0)
                {                    
                    factura.Id = facturas.Count > 0 ? facturas.Max(x => x.Id) + 1 : 1;
                    facturas.Add(factura);
                    return true;
                }
                else
                {
                    ModelState.AddModelError("", "No puede guardar facturas sin detalle");
                }
            }
            return false;
        }
    }
}
