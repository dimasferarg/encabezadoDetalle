﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Json;
using System.Web.Script.Serialization;
using System.Net;
using HeaderDetalle.Models;

namespace HeaderDetalle.Models
{
    //********************************** TABLA BOBINASD *****************************************************

    public class BobinasDService
    {
        string BASE_URL = "http://localhost:2768/ServicioProduccion.svc/";
        public List<BobinasDWS> SeleccionarTodos()
        {
            try
            {
                var webCliente = new WebClient();
                var json = webCliente.DownloadString(BASE_URL + "seleccionarbobinasD");
                string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
                json = s;
                var js = new JavaScriptSerializer();
                return js.Deserialize<List<BobinasDWS>>(json);
            }
            catch
            {
                return null;
            }
        }
        public BobinasDWS Seleccionar(string id)
        {
            try
            {
                var webCliente = new WebClient();
                string url = string.Format(BASE_URL + "seleccionarbobinaD/{0}", id);
                var json = webCliente.DownloadString(url);
                string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
                json = s;
                var js = new JavaScriptSerializer();
                return js.Deserialize<BobinasDWS>(json);
            }
            catch
            {
                return null;
            }
        }

        public bool Agregar(BobinasDWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(BobinasDWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "agregarbobinaD", "POST", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Editar(BobinasDWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(BobinasDWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "editarbobinaD", "PUT", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Eliminar(BobinasDWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(BobinasDWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "eliminarbobinaD", "DELETE", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

    }

    //********************************** TABLA BOBINASH *****************************************************

    public class BobinasHService
    {
        string BASE_URL = "http://localhost:2768/ServicioProduccion.svc/";
        public List<BobinasHWS> SeleccionarTodos()
        {
            try
            {
                var webCliente = new WebClient();
                var json = webCliente.DownloadString(BASE_URL + "seleccionarbobinasH");
                string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
                json = s;
                var js = new JavaScriptSerializer();
                return js.Deserialize<List<BobinasHWS>>(json);
            }
            catch
            {
                return null;
            }
        }
        public BobinasHWS Seleccionar(string id)
        {
            try
            {
                var webCliente = new WebClient();
                string url = string.Format(BASE_URL + "seleccionarbobinaH/{0}", id);
                var json = webCliente.DownloadString(url);
                string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
                json = s;
                var js = new JavaScriptSerializer();
                return js.Deserialize<BobinasHWS>(json);
            }
            catch
            {
                return null;
            }
        }

        public bool Agregar(BobinasHWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(BobinasHWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "agregarbobinaH", "POST", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Editar(BobinasHWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(BobinasHWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "editarbobinaH", "PUT", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Eliminar(BobinasHWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(BobinasHWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "eliminarbobinaH", "DELETE", data);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    //********************************** TABLA Productos *****************************************************

    public class ProductosService
    {
        string BASE_URL = "http://localhost:2768/ServicioProduccion.svc/";
        public List<ProductosWS> SeleccionarTodos()
        {
            try
            {
                var webCliente = new WebClient();
                var json = webCliente.DownloadString(BASE_URL + "seleccionarproductos");
                string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
                json = s;
                var js = new JavaScriptSerializer();
                return js.Deserialize<List<ProductosWS>>(json);
            }
            catch
            {
                return null;
            }
        }
        public ProductosWS Seleccionar(string id)
        {
            try
            {
                var webCliente = new WebClient();
                string url = string.Format(BASE_URL + "seleccionarproducto/{0}", id);
                var json = webCliente.DownloadString(url);
                string s = json.Replace("Ã³", "ó").Replace("Ã©", "é").Replace("Ã±", "ñ").Replace("Ãº", "ú").Replace("Ã­", "í").Replace("Ã¡", "á").Replace("Í", "Í");
                json = s;
                var js = new JavaScriptSerializer();
                return js.Deserialize<ProductosWS>(json);
            }
            catch
            {
                return null;
            }
        }

        public bool Agregar(ProductosWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ProductosWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "agregarProductos", "POST", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Editar(ProductosWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ProductosWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "editarProductos", "PUT", data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Eliminar(ProductosWS ws)
        {
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ProductosWS));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, ws);
                string data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);
                WebClient webcliente = new WebClient();
                webcliente.Headers["Content-type"] = "application/json";
                webcliente.Encoding = Encoding.UTF8;
                webcliente.UploadString(BASE_URL + "eliminarProductos", "DELETE", data);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}