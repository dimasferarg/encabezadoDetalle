﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HeaderDetalle.Models
{
    public class BobinasHWS
    {
        public int ID { get; set; }
        public int EmpleadoID { get; set; }
        public DateTime Fecha { get; set; }
        public int Anulado { get; set; }
        public ICollection<BobinasDWS> DetalleBobinas { get; set; }
        public BobinasHWS()
        {
            this.DetalleBobinas = new HashSet<BobinasDWS>();
        }
    }
}