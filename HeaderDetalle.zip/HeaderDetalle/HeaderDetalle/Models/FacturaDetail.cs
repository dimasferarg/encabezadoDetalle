﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HeaderDetalle.Models
{
    public class FacturaDetail
    {
        public int FacturaID { get; set; }
        public int ProductoID { get; set; }
        public decimal Precio { get; set; }
        public decimal Cantidad { get; set; }
    }
}